import React from "react";
import Navigators from "./navigation/Navigators";
// import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  return (
    <div >
<Navigators/>
    </div>
  );
}

export default App;
