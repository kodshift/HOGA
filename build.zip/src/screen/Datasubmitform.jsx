import { useState } from "react";
import { Formik } from "formik";
import * as Yup from "yup";
import facebook from "../assets/facebook.png";
import instagram from "../assets/instagram.png";
// import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
// import Profilelist from "../redux/Profilelist";
// import Profile
// import Select from "react-select";

const Datasubmitform = () => {
  const navigate = useNavigate();

  const [imagePath, setImagePath] = useState("");
  const [name, setName] = useState("");
  console.log("====================================");

  console.log("====================================");

  console.log(imagePath);

  const schema = Yup.object().shape({
    username: Yup.string().required("Username is a required field"),
    age: Yup.number()
      .required("Age is a required field")
      .positive("Age must be a positive number"),
    height: Yup.number()
      .required("Height is a required field")
      .positive("Height must be a positive number"),
    religion: Yup.string().required("Religion is a required field"),
    casteSubcaste: Yup.string().required("Caste/Subcaste is a required field"),
    caste: Yup.string().required("Caste is a required field"),
    country: Yup.string().required("Country is a required field"),
    state: Yup.string().required("State is a required field"),
    city: Yup.string().required("City is arequired field"),
    colormen: Yup.string().required("Color is required field"),
    weight: Yup.number()
      .required("Weight s a required field")
      .positive("Weight be a positive no"),
    smoke: Yup.string().required("Smoking preference is required"),
    motherTongue: Yup.string().required("Mother tongue is a required feild"),
    annualIncome: Yup.number()
      .required("Annual income is a required field")
      .positive("Annual income must be a positive number"),
    bloodGroup: Yup.string().required("Blood group is a required field"),
    diet: Yup.string().required("Diet is a required field"),
    gender: Yup.string().required("Diet is a required field"),
    dateOfBirth: Yup.date().required("Date of birth is a required field"),
    maritalStatus: Yup.string().required("Marital is a required field"),
    occupation: Yup.string().required("Occupation is a required field"),
    education: Yup.string().required("Education is a required field"),
    location: Yup.string().required("Education is a required field"),
    whatsappNo: Yup.number()
      .required("Whatsapp  number is a required field")
      .positive("whatsapp no be a positive no"),
    mobileNo: Yup.number()
      .required("Mobile no is a required field")
      .positive("mobile no be a positive no"),
    message: Yup.string().required("please write some message"),
  });

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePath(reader.result); // Set the file path in state
      };
      reader.readAsDataURL(file);
    }
  };

  const sendDataToApi = (
    username,
    age,
    height,
    religion,
    casteSubcaste,
    caste,
    country,
    state,
    city,
    colormen,
    weight,
    smoke,
    motherTongue,
    annualIncome,
    bloodGroup,
    diet,
    gender,
    dateOfBirth,
    maritalStatus,
    occupation,
    education,
    location,
    whatsappNo,
    mobileNo,
    message
    // imagePath
    // imagePath
  ) => {
    fetch(
      "https://hogamilan-bc801-default-rtdb.firebaseio.com/hogamilan.json",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username,
          age,
          height,
          religion,
          casteSubcaste,
          caste,
          country,
          state,
          city,
          colormen,
          weight,
          smoke,
          motherTongue,
          annualIncome,
          bloodGroup,
          diet,
          gender,
          dateOfBirth,
          maritalStatus,
          occupation,
          education,
          location,
          whatsappNo,
          mobileNo,
          message,
          imagePath,
          // imagePath
        }),
      }
    )
      .then((response) => response.json())
      .then((data) => {
        // Handle response from API if needed
        console.log("Data sent successfully to API:", data);
      })
      .catch((error) => {
        console.error("Error sending data to API:", error);
      });
  };

  const getData = async (values) => {
    console.log("====================================");
    console.log(values.username);
    console.log("====================================");
    const Username = localStorage.setItem("username", values.username);
    const {
      username,
      age,
      height,
      religion,
      casteSubcaste,
      caste,
      country,
      state,
      city,
      colormen,
      weight,
      smoke,
      motherTongue,
      annualIncome,
      bloodGroup,
      diet,
      gender,
      dateOfBirth,
      maritalStatus,
      occupation,
      education,
      location,
      whatsappNo,
      mobileNo,
      message,
      // imagePath
    } = values;

    sendDataToApi(
      username,
      age,
      height,
      religion,
      casteSubcaste,
      caste,
      country,
      state,
      city,
      colormen,
      weight,
      smoke,
      motherTongue,
      annualIncome,
      bloodGroup,
      diet,
      gender,
      dateOfBirth,
      maritalStatus,
      occupation,
      education,
      location,
      whatsappNo,
      mobileNo,
      message,
      imagePath
    );
    navigate("/");
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignTracks: "center",
          width: "100%",
          height: "110px",
          backgroundColor: "black",
        }}
      >
        <p
          style={{
            color: "white",
            fontSize: "30px",
            fontFamily: "monospace",
            fontWeight: "bold",
            marginTop:'20px'
            // textAlign:"center"
          }}
        >
         {localStorage.getItem('username')}
        </p>
      </div>
      <div style={{ paddingLeft: "40px", paddingTop: "20px" }}>
        <p style={{ fontSize: "28px", fontWeight: "400" }}>
          Update Your Profile
        </p>

        <Formik
          validationSchema={schema}
          initialValues={{
            username: "",
            age: "",
            height: "",
            religion: "",
            casteSubcaste: "",
            caste: "",
            country: "",
            state: "",
            city: "",
            colormen: "",
            weight: "",
            smoke: "",
            motherTongue: "",
            annualIncome: "",
            bloodGroup: "",
            diet: "",
            gender: "",
            dateOfBirth: "",
            maritalStatus: "",
            occupation: "",
            education: "",
            location: "",
            whatsappNo: "",
            mobileNo: "",
            message: "",
          }}
          onSubmit={getData}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            handleSubmit,
          }) => (
            <div>
              <form noValidate onSubmit={handleSubmit}>
                <div
                  style={{
                    display: "flex",
                    gap: "30px ",
                    flexDirection: "row",
                    width: "80%",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label>Full Name</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        paddingLeft: "10px",
                        borderColor: "#F2F2F2",
                        transition: "border-color 0.3s ease",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="username"
                      name="username"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.username}
                      // placeholder="Enter username"
                      id="username"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.username && touched.username && errors.username}
                    </p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label>Age</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        paddingLeft: "10px",
                        borderColor: "#F2F2F2",
                        transition: "border-color 0.3s ease",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="age"
                      name="age"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.age}
                      // placeholder="Enter username"
                      id="age"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.age && touched.age && errors.age}
                    </p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Height</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        paddingLeft: "10px",
                        borderColor: "#F2F2F2",
                        transition: "border-color 0.3s ease",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="height"
                      name="height"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.height}
                      // placeholder="Enter username"
                      id="height"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.height && touched.height && errors.height}
                    </p>
                  </div>
                </div>
                <div
                  style={{
                    display: "flex",
                    gap: "30px",
                    marginTop: "20px",
                    flexDirection: "row",
                    width: "80%",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Religion:</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        paddingLeft: "10px",
                        transition: "border-color 0.3s ease",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="religion"
                      name="religion"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.religion}
                      // placeholder="Enter username"
                      id="religion"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.religion && touched.religion && errors.religion}
                    </p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Caste</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        paddingLeft: "10px",
                        transition: "border-color 0.3s ease",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="caste"
                      name="caste"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.caste}
                      // placeholder="Enter username"
                      id="caste"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.caste && touched.caste && errors.caste}
                    </p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Subcaste</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        paddingLeft: "10px",
                        transition: "border-color 0.3s ease",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="casteSubcaste"
                      name="casteSubcaste"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.casteSubcaste}
                      // placeholder="Enter username"
                      id="casteSubcaste"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.casteSubcaste &&
                        touched.casteSubcaste &&
                        errors.casteSubcaste}
                    </p>
                  </div>
                </div>
                <div
                  style={{
                    display: "flex",
                    gap: "30px",
                    marginTop: "20px",
                    flexDirection: "row",
                    width: "80%",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Country</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        transition: "border-color 0.3s ease",
                        paddingLeft: "10px",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="country"
                      name="country"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.country}
                      // placeholder="Enter username"
                      id="country"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.country && touched.country && errors.country}
                    </p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1"> Your States</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        paddingLeft: "10px",
                        transition: "border-color 0.3s ease",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="state"
                      name="state"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.state}
                      // placeholder="Enter username"
                      id="state"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.state && touched.state && errors.state}
                    </p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1"> Your City</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        paddingLeft: "10px",
                        transition: "border-color 0.3s ease",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="city"
                      name="city"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.city}
                      // placeholder="Enter username"
                      id="city"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.city && touched.city && errors.city}
                    </p>
                  </div>
                </div>
                <div
                  style={{
                    display: "flex",
                    gap: "30px",
                    marginTop: "20px",
                    flexDirection: "row",
                    width: "80%",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Colour</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        transition: "border-color 0.3s ease",
                        paddingLeft: "10px",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="colormen"
                      name="colormen"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.colormen}
                      // placeholder="Enter username"
                      id="colormen"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.colormen && touched.colormen && errors.colormen}
                    </p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Weight</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        paddingLeft: "10px",
                        transition: "border-color 0.3s ease",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="weight"
                      name="weight"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.weight}
                      // placeholder="Enter username"
                      id="weight"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.weight && touched.weight && errors.weight}
                    </p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Smoke</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        paddingLeft: "10px",
                        transition: "border-color 0.3s ease",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="smoke"
                      name="smoke"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.smoke}
                      // placeholder="Enter username"
                      id="smoke"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.smoke && touched.smoke && errors.smoke}
                    </p>
                  </div>
                </div>
                <div
                  style={{
                    display: "flex",
                    gap: "30px",
                    marginTop: "20px",
                    flexDirection: "row",
                    width: "80%",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Mother Tongue</label>

                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        paddingLeft: "10px",
                        transition: "border-color 0.3s ease",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="motherTongue"
                      name="motherTongue"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.motherTongue}
                      // placeholder="Enter username"
                      id="motherTongue"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.motherTongue &&
                        touched.motherTongue &&
                        errors.motherTongue}
                    </p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Annual Income:</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        paddingLeft: "10px",
                        transition: "border-color 0.3s ease",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="annualIncome"
                      name="annualIncome"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.annualIncome}
                      // placeholder="Enter username"
                      id="annualIncome"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.annualIncome &&
                        touched.annualIncome &&
                        errors.annualIncome}
                    </p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Blood Group</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        transition: "border-color 0.3s ease",
                        paddingLeft: "10px",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="bloodGroup"
                      name="bloodGroup"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.bloodGroup}
                      // placeholder="Enter username"
                      id="bloodGroup"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.bloodGroup &&
                        touched.bloodGroup &&
                        errors.bloodGroup}
                    </p>
                  </div>
                </div>
                <div
                  style={{
                    display: "flex",
                    gap: "30px",
                    marginTop: "20px",
                    flexDirection: "row",
                    width: "80%",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Diet</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        transition: "border-color 0.3s ease",
                        paddingLeft: "10px",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="diet"
                      name="diet"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.diet}
                      // placeholder="Enter username"
                      id="diet"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.diet && touched.diet && errors.diet}
                    </p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Gender</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        paddingLeft: "10px",
                        transition: "border-color 0.3s ease",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="gender"
                      name="gender"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.gender}
                      // placeholder="Enter username"
                      id="gender"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.gender && touched.gender && errors.gender}
                    </p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Date of birth</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        paddingLeft: "10px",
                        transition: "border-color 0.3s ease",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="dateOfBirth"
                      name="dateOfBirth"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.dateOfBirth}
                      // placeholder="Enter username"
                      id="dateOfBirth"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.dateOfBirth &&
                        touched.dateOfBirth &&
                        errors.dateOfBirth}
                    </p>
                  </div>
                </div>
                <div
                  style={{
                    display: "flex",
                    gap: "30px",
                    marginTop: "20px",
                    flexDirection: "row",
                    width: "80%",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Marital Status</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        paddingLeft: "10px",
                        transition: "border-color 0.3s ease",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="maritalStatus"
                      name="maritalStatus"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.maritalStatus}
                      // placeholder="Enter username"
                      id="maritalStatus"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.maritalStatus &&
                        touched.maritalStatus &&
                        errors.maritalStatus}
                    </p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Occupation</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        transition: "border-color 0.3s ease",
                        paddingLeft: "10px",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="occupation"
                      name="occupation"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.occupation}
                      // placeholder="Enter username"
                      id="occupation"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.occupation &&
                        touched.occupation &&
                        errors.occupation}
                    </p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Education</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        paddingLeft: "10px",
                        transition: "border-color 0.3s ease",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="education"
                      name="education"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.education}
                      // placeholder="Enter username"
                      id="education"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.education &&
                        touched.education &&
                        errors.education}
                    </p>
                  </div>
                </div>
                <div
                  style={{
                    display: "flex",
                    gap: "30px",
                    marginTop: "20px",
                    flexDirection: "row",
                    width: "80%",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Location</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        transition: "border-color 0.3s ease",
                        paddingLeft: "10px",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="location"
                      name="location"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.location}
                      // placeholder="Enter username"
                      id="location"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.location && touched.location && errors.location}
                    </p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">WhatsApp</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        transition: "border-color 0.3s ease",
                        paddingLeft: "10px",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="whatsappNo"
                      name="whatsappNo"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.whatsappNo}
                      // placeholder="Enter username"
                      id="whatsappNo"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.whatsappNo &&
                        touched.whatsappNo &&
                        errors.whatsappNo}
                    </p>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      width: "30%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Mobile Number</label>
                    <input
                      style={{
                        width: "100%",
                        cursor: "pointer",
                        transition: "border-color 0.3s ease",
                        paddingLeft: "10px",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      type="mobileNo"
                      name="mobileNo"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.mobileNo}
                      // placeholder="Enter username"
                      id="mobileNo"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.mobileNo && touched.mobileNo && errors.mobileNo}
                    </p>
                  </div>
                </div>
                <div
                  style={{
                    display: "flex",
                    width: "95.5%",
                    marginTop: "20px",
                    flexDirection: "row", // Change to row to align items horizontally
                  }}
                >
                  {/* Add to Gallery Button */}

                  <div
                    style={{
                      display: "flex",
                      width: "100%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Gallery</label>
                    {/* Input Field for Uploading Image */}
                    <input
                      style={{
                        display: "flex",
                        //   flex: "1", // Let the input field take remaining space
                        cursor: "pointer",
                        transition: "border-color 0.3s ease",
                        //   paddingLeft: "10px",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "30px",
                      }}
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }}
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }}
                      type="file" // Use type="file" for uploading files
                      id="input1"
                      accept="image/*" // Accept only image files
                      onChange={handleImageChange} // Call handleImageChange when image is selected
                    />
                  </div>
                </div>

                <div
                  style={{
                    display: "flex",
                    gap: "30px",
                    marginTop: "20px",
                    flexDirection: "row",
                    width: "80%",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      width: "95%",
                      flexDirection: "column",
                    }}
                  >
                    <label htmlFor="input1">Description</label>
                    <input
                      style={{
                        width: "100%",
                        //   height:"90px",
                        cursor: "pointer",
                        transition: "border-color 0.3s ease",
                        paddingLeft: "10px",
                        borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "250px",
                      }}
                      type="message"
                      name="message"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.message}
                      // placeholder="Enter username"
                      id="message"
                      onMouseEnter={(e) => {
                        e.target.style.borderColor = "#87CEFA";
                      }} // Change border color on hover
                      onMouseLeave={(e) => {
                        e.target.style.borderColor = "#F2F2F2";
                      }} // Revert border color on mouse leave
                    />
                    <p
                      style={{
                        margi: "0 0 10px 10px",
                        textAlign: "ceter",
                        fontSize: "10px",
                        color: "red",
                      }}
                    >
                      {errors.message && touched.message && errors.message}
                    </p>
                  </div>
                </div>
                <div
                  style={{
                    display: "flex",
                    gap: "30px",
                    marginTop: "20px",
                    flexDirection: "row",
                    width: "80%",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      // width: "20%",
                      flexDirection: "column",
                    }}
                  >
                    <button
                      type="submit"
                      style={{
                        // width: "100%",
                        //   height:"90px",
                        cursor: "pointer",
                        backgroundColor: "#DC3545",
                        //   transition: "border-color 0.3s ease",
                        //   paddingLeft: "10px",
                        //   borderColor: "#F2F2F2",
                        borderWidth: "3px",
                        height: "35px",
                      }}
                    >
                      Submit
                    </button>
                  </div>
                </div>
              </form>
            </div>
          )}
        </Formik>
      </div>
      <div>
        <div
          style={{
            display: "flex",
            width: "100%",
            height: "100%",
            marginTop: "20px",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              width: "40%",
              height: "100%",
              // height:"100%",
              // backgroundColor: "red",
            }}
          >
            <span style={{ fontSize: "25px", fontWeight: "700" }}>
              About <span style={{ color: "#DC3545" }}>Hogamilan</span>
            </span>
            <span>Discover lasting connections with</span>
            <span>Hogamilan.com, your trusted</span>
            <span>matrimony platform. Explore</span>
            <span>personalized matchmaking and</span>
            <span>matrimonial services for a</span>
            <span>meaningful journey to love.</span>
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                marginTop: "20px",
                gap: "20px",
              }}
            >
              <img style={{ width: "40px" }} src={facebook} />
              <img style={{ width: "40px" }} src={instagram} />
            </div>
          </div>
          <div
            style={{
              display: "flex",
              width: "25%",
              height: "100%",
              marginBottom: "90px",
              flexDirection: "column",
              // backgroundColor: "green",
            }}
          >
            <span style={{ fontSize: "25px", fontWeight: "700" }}>
              Quick <span>Links</span>
            </span>
            <span>About Us</span>
            <span>Blog</span>
            <span>Contact Us</span>
          </div>
          <div
            style={{
              display: "flex",
              width: "25%",
              height: "100%",
              marginBottom: "90px",
              // backgroundColor: "blue",
              flexDirection: "column",
            }}
          >
            <span style={{ fontSize: "25px", fontWeight: "700" }}>Policy</span>
            <span>Disclaimer</span>
            <span>Privacy Policy</span>
            <span>Terms of service</span>
            <span>FAQs</span>
          </div>
        </div>
      </div>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          width: "100%",
          marginTop: "90px",
          backgroundColor: "#DC3545",
          height: "60px",
          // marginTop: "150px",
        }}
      >
        <p style={{ fontSize: "15px", fontWeight: "bold", color: "white" }}>
          Copyright © 2024 - Hogamilan - All Rights Reserved
        </p>
      </div>
    </div>
  );
};

export default Datasubmitform;
