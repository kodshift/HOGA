import React, { useState, useEffect } from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import { useSelector, useDispatch } from "react-redux";
import { getAllData } from "../redux/Profilelist";
import Avatar from "@mui/material/Avatar";

const columns = [
  { id: "Image", label: "Image", minWidth: 170 },
  { id: "Username", label: "Username", minWidth: 100 },
  {
    id: "age",
    label: "age",
    minWidth: 170,
    align: "right",
    format: (value) => value.toLocaleString("en-US"),
  },
  {
    id: "height",
    label: "height",
    minWidth: 170,
    align: "right",
    format: (value) => value.toLocaleString("en-US"),
  },
  {
    id: "CasteSubcaste",
    label: "CasteSubcaste",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "Caste",
    label: "Caste",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "Country",
    label: "Country",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "State",
    label: "State",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "City",
    label: "City",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "Colormen",
    label: "Colormen",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "Weight",
    label: "Weight",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "Smoke",
    label: "Smoke",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "Mothertongue",
    label: "Mothertongue",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "AnnualIncome",
    label: "AnnualIncome",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "Bloodgroup",
    label: "Bloodgroup",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "Diet",
    label: "Diet",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "gender",
    label: "gender",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "Dateofbirth",
    label: "Dateofbirth",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "Maritalstatus",
    label: "Maritalstatus",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "Occupation",
    label: "Occupation",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "Education",
    label: "Education",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "Location",
    label: "Location",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "WhatsappNo",
    label: "Whatsapp-No",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "MobileNo",
    label: "Mobile-No",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
  {
    id: "Message",
    label: "Message",
    minWidth: 170,
    align: "right",
    format: (value) => value.toFixed(2),
  },
];

function Adminpages() {
  const datastore = useSelector((state) => state.Profiledata.users);
  const Item = datastore.map((item, index) => {});
  function createData(
    Image,
    Username,
    age,
    height,
    CasteSubcaste,
    Caste,
    Country,
    State,
    City,
    Colormen,
    Weight,
    Smoke,
    Mothertongue,
    AnnualIncome,
    Bloodgroup,
    Diet,
    gender,
    Dateofbirth,
    Maritalstatus,
    Occupation,
    Education,
    Location,
    WhatsappNo,
    MobileNo,
    Message
  ) {
    //   const density = population / size;
    return {
      Image,
      Username,
      age,
      height,
      CasteSubcaste,
      Caste,
      Country,
      State,
      City,
      Colormen,
      Weight,
      Smoke,
      Mothertongue,
      AnnualIncome,
      Bloodgroup,
      Diet,
      gender,
      Dateofbirth,
      Maritalstatus,
      Occupation,
      Education,
      Location,
      WhatsappNo,
      MobileNo,
      Message,
    };
  }

  const rows = datastore.map((user, index) => {
    return createData(
      <Avatar
        alt="Remy Sharp"
        src={user.imagePath}
        sx={{ width: 60, height: 60 }}
      />,
      // user.imagePath,
      user.username,
      user.age,
      user.height,
      user.casteSubcaste,
      user.caste,
      user.country,
      user.state,
      user.city,
      user.colormen,
      user.weight,
      user.smoke,
      user.motherTongue,
      user.annualIncome,
      user.bloodGroup,
      user.diet,
      user.gender,
      user.dateOfBirth,
      user.maritalStatus,
      user.occupation,
      user.education,
      user.location,
      user.whatsappNo,
      user.mobileNo,
      user.message
    );
  });

  //   const dataArray = Object.values(datastore);

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getAllData());
  }, [dispatch]);

  console.log("====================================");
  console.log(datastore, "datstore");
  console.log("====================================");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  return (
    <Paper style={{ width: "100%", overflow: "hidden" }}>
      <TableContainer style={{ maxHeight: 440 }}>
        <Table stickyHeader aria-label="sticky table">
          <TableHead>
            <TableRow>
              {columns.map((column) => (
                <TableCell
                  key={column.id}
                  align={column.align}
                  style={{ minWidth: column.minWidth }}
                >
                  {column.label}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((row) => {
                return (
                  <TableRow hover role="checkbox" tabIndex={-1} key={row.code}>
                    {columns.map((column) => {
                      const value = row[column.id];
                      return (
                        <TableCell key={column.id} align={column.align}>
                          {column.format && typeof value === "number"
                            ? column.format(value)
                            : value}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                );
              })}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[10, 25, 100]}
        component="div"
        count={rows.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </Paper>
  );
}
export default Adminpages;
