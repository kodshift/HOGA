import React from "react";
import Logo from "../assets/logo.jpg";
import { useNavigate } from "react-router-dom";

function Navbar() {
  const navigate = useNavigate();
  return (
    <div>
      <nav class="navbar bg-white">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">
            <img
              style={{
                backgroundColor: "transparent",
              }}
              onClick={() => {
                navigate("/");
              }}
              src={Logo}
              alt="Logo"
              width="70"
              height="74"
              border="none"
              class="d-inline-block align-text-top"
            />
          </a>
        </div>
      </nav>
    </div>
  );
}

export default Navbar;
