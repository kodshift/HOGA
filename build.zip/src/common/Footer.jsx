import React from 'react'

function Footer() {
  return (
    <>
    <div
    style={{
      display: "flex",
      width: "100%",
      height: "100%",
      justifyContent: "center",
      alignItems: "center",
    }}
  >
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        width: "25%",
        height: "100%",
        // height:"100%",
        // backgroundColor: "red",
      }}
    >
      <span style={{ fontSize: "25px", fontWeight: "700" }}>
        About <span style={{ color: "#DC3545" }}>Hogamilan</span>
      </span>
      <span>Discover lasting connections with</span>
      <span>Hogamilan.com, your trusted</span>
      <span>matrimony platform. Explore</span>
      <span>personalized matchmaking and</span>
      <span>matrimonial services for a</span>
      <span>meaningful journey to love.</span>
    </div>
    <div
      style={{
        display: "flex",
        width: "25%",
        height: "100%",
        flexDirection: "column",
        // backgroundColor: "green",
      }}
    >
    <span style={{ fontSize: "25px", fontWeight: "700" }}>
    Quick <span >Links</span>
  </span>
      <span>Discover lasting connections with</span>
      <span>Hogamilan.com, your trusted</span>
      <span>matrimony platform. Explore</span>
      <span>personalized matchmaking and</span>
      <span>matrimonial services for a</span>
      <span>meaningful journey to love.</span>
    </div>
    <div
      style={{
        display: "flex",
        width: "25%",
        height: "100%",
        // backgroundColor: "blue",
        flexDirection: "column",
      }}
    >
    <span style={{ fontSize: "25px", fontWeight: "700" }}>
    Policy
  </span>
      <span>Discover lasting connections with</span>
      <span>Hogamilan.com, your trusted</span>
      <span>matrimony platform. Explore</span>
      <span>personalized matchmaking and</span>
      <span>matrimonial services for a</span>
      <span>meaningful journey to love.</span>
    </div>
  
  </div>

  <Footer />
  </>
  
  )
}

export default Footer
