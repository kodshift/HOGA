// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {  getAuth } from 'firebase/auth';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyB-occcoBUrnjlps58gqc9D6IhrX2vak9U",
  authDomain: "hogamilan-bc801.firebaseapp.com",
  projectId: "hogamilan-bc801",
  storageBucket: "hogamilan-bc801.appspot.com",
  messagingSenderId: "1048498556284",
  appId: "1:1048498556284:web:b1cfaea1c53362ce1d68f9",
  measurementId: "G-P2RPBLLMYF"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const database = getAuth(app);


//   for hosting website 
// cmd ->  npm install -g firebase-tools 
// const analytics = getAnalytics(app);