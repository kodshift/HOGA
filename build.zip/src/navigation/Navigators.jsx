import React, { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Homepage from "../pages/Homepage";
import Navbar from "../common/Navbar";
import Loginpage from "../pages/Loginpage";
import Signuppage from "../pages/Signuppage";
import Datasubmitform from "../screen/Datasubmitform";
import Errorscreen from "../screen/Errorscreen";
import Forgotpassword from "../screen/Forgotpassword";
import Profilepage from "../pages/Profilepage";
import Adminpage from "../pages/Adminpage";
import Admindashboard from "../pages/Admindashboard";
import Adminpages from "../screen/Adminpages";

const Navigators = () => {

  // const 
  
  
  return (
    <BrowserRouter>
    <Navbar/>
      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/Loginpage" element={<Loginpage />} />
        <Route path="/Signuppage" element={<Signuppage />} />
        <Route path="/Datasubmitform" element={<Datasubmitform />} />
        <Route path="/Forgotpassword" element={<Forgotpassword />} />
        <Route path="/Profilepage" element={<Profilepage />} />
        <Route path="/Adminpage" element={<Adminpage />} />
        <Route path="/Admindashboard" element={<Admindashboard />} />
   
  
        <Route path="*" element={<Errorscreen />} />
      </Routes>
    </BrowserRouter>
  );
};
export default Navigators;
