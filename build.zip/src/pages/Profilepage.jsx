import React from 'react'
import { useSelector, shallowEqual, useDispatch } from 'react-redux'
import { addUser } from '../redux/Cart';

function Profilepage() {
  const dispatch = useDispatch();
  // const nameofuser = "shalu"
  // dispatch(addUser(nameofuser))
  const Profilename = "shyambapu";
  dispatch(addUser(Profilename));

  const data = useSelector(state => state.Cartitem);
  console.log('====================================');
  console.log(data, 'datagot');
  console.log('====================================');

  // const data = useSelector(state => state.Cartitem);
  // console.log('====================================');
  // console.log(data, 'bhokalopo');
  // console.log('====================================');
  //   const listedItems = useSelector(state => state.productsItem);
  return (
    <div>
    Profilepage
    </div>
  )
}

export default Profilepage
