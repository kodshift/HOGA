import { useEffect, useState, useRef } from "react";
// import React, { useState } from "react";
import { Grid, Paper } from "@mui/material";
import "./Hompepage.css";
// import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
// import facebook from "../assets/facebook.png";
// import instagram from "../assets/instagram.png";
import { useSelector, useDispatch } from "react-redux";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import facebook from "../assets/facebook.png";
import instagram from "../assets/instagram.png";
import Avatar from "@mui/material/Avatar";
import whatsapp from "../assets/whatsapp.png";
import call from "../assets/call.png";
import Snow from "../snow/Snow";
import { getAllData } from "../redux/Profilelist";
import { useNavigate } from "react-router-dom";
import isEqual from "lodash/isEqual";
// import Profilepage from "./Profilepage";
import { Modal } from "@mui/material";
import "./Modal.css";
import { addUser } from "../redux/Cart";
// import bannerone from "../assets/bannerone";
function Homepage() {
  const [searchvalues, setSearchvalues] = useState({
    gender: "",
    age: "",
    occupation: "",
    caste: "",
    color: "",
    height: "",
    city: "",
    religion: "",
  });
  const [openModal, setOpenModal] = useState(false);
  const [matchingProfiles, setMatchingProfiles] = useState([]);
  const [showMatchingCarousel, setShowMatchingCarousel] = useState(false); // Track whether to show the carousel with matching profiles

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    dispatch(getAllData());
  }, [dispatch]);

  const datastore = useSelector((state) => state.Profiledata.users);
  const dataArray = Object.values(datastore);

  // useEffect(() => {
  //   document.body.style.backgroundColor = "black";
  //   return () => {
  //     document.body.style.backgroundColor = "";
  //   };
  // }, []);

  const [sortedData, setSortedData] = useState([]);
  const prevSearchValues = useRef(searchvalues);

  useEffect(() => {
    if (!isEqual(prevSearchValues.current, searchvalues)) {
      const sorted = dataArray.sort((a, b) => {
        for (const key of Object.keys(searchvalues)) {
          if (a[key] && b[key]) {
            if (
              a[key].toLowerCase().startsWith(searchvalues[key].toLowerCase())
            ) {
              return -1;
            } else if (
              b[key].toLowerCase().startsWith(searchvalues[key].toLowerCase())
            ) {
              return 1;
            }
          }
        }
        return 0;
      });
      setSortedData(sorted);
      prevSearchValues.current = searchvalues;
    }
  }, [searchvalues, dataArray]);

  useEffect(() => {
    applySorting(datastore);
  }, [datastore]);

  const applySorting = (data) => {
    const sorted = dataArray.sort((a, b) => {
      for (const key of Object.keys(searchvalues)) {
        if (a[key] && b[key]) {
          if (
            a[key].toLowerCase().startsWith(searchvalues[key].toLowerCase())
          ) {
            return -1;
          } else if (
            b[key].toLowerCase().startsWith(searchvalues[key].toLowerCase())
          ) {
            return 1;
          }
        } else if (a[key] && !b[key]) {
          return -1;
        } else if (!a[key] && b[key]) {
          return 1;
        }
      }
      return 0;
    });
    setSortedData(sorted);
  };

  useEffect(() => {
    if (!isEqual(prevSearchValues.current, searchvalues)) {
      const sorted = Object.values(data).sort((a, b) =>
        Object.keys(searchvalues).reduce((acc, key) => {
          if (a[key] && b[key]) {
            return acc ||
              a[key].toLowerCase().startsWith(searchvalues[key].toLowerCase())
              ? -1
              : b[key].toLowerCase().startsWith(searchvalues[key].toLowerCase())
              ? 1
              : 0;
          }
          return acc;
        }, 0)
      );
      setSortedData(sorted);
      prevSearchValues.current = searchvalues;
    }
  }, [searchvalues]);
  const [showContent, setShowContent] = useState(false);
  const [item, setItem] = useState(false);
  const [data, setData] = useState(false);
  const [store, setStore] = useState(false);
  const [dataitem, setDataitem] = useState(false);
  const [storeitem, setStoreitem] = useState(false);
  const [mount, setMount] = useState(false);

  const toggleContent = () => {
    setShowContent(!showContent);
  };

  const handleOpen = () => {
    setItem(!item);
  };

  const handleClose = () => {
    setData(!data);
  };

  const handleData = () => {
    setDataitem(!dataitem);
  };

  const handleStore = () => {
    setStore(!store);
  };

  const handleStoreItem = () => {
    setStoreitem(!storeitem);
  };

  const handleMount = () => {
    setMount(!mount);
  };

  const handleWhatsAppClick = (userData) => {
    console.log("====================================");
    console.log(userData, "gotdataofuser");
    console.log("====================================");
    dispatch(addUser(userData));
    const phoneNumber = "917568111771";
    const message = `Hi, I'm interested in your profile. My name is ${userData.username}, age is ${userData.age}, caste is ${userData.caste}, city is ${userData.city}, gender is ${userData.gender}, occupation is ${userData.occupation}, religion is ${userData.religion}, whatsapp no ${userData.whatsappNo}, education ${userData.education}, annualicome ${userData.annualIncome}, Image ${userData.imagePath}  and state is ${userData.state}.`;
    const encodedMessage = encodeURIComponent(message);
    const url = `https://api.whatsapp.com/send?phone=${phoneNumber}&text=${encodedMessage}`;
    window.open(url, "_blank");
  };

  const handleFormSubmit = (formData) => {
    const matches = sortedData.filter((profile) => {
      return Object.keys(formData).some((key) => {
        return profile[key] === formData[key];
      });
    });
    setMatchingProfiles(matches);
    setShowMatchingCarousel(matches.length > 0); // Show the matching carousel if there are matches
    setOpenModal(false);

    if (matches.length > 0) {
      alert(`Found ${matches.length} matching profiles.`);
    } else {
      alert("No matching profiles found.");
    }
  };

  const responsive = {
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 3,
      slidesToSlide: 3,
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2,
      slidesToSlide: 2,
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1,
      slidesToSlide: 1,
    },
  };

  const datastorage = [
    {
      image: "https://sundarjodi.com/img/5marathi-couple.png",
      profile: {
        name: "JPragati & Rahul",
        occupation:
          "Perfect for what i needed. Found my Lenders almost instantly. who use again. Perfect for what i needed. Found my Lenders almost instantly. who use again.",
        // location: "New York",
      },
    },
    {
      image: "https://sundarjodi.com/img/4marathi-couple.png",
      profile: {
        name: "Ankita & Rajesh",
        occupation:
          "Perfect for what i needed. Found my Lenders almost instantly. who use again. Perfect for what i needed. Found my Lenders almost instantly. who use again.",
        // location: "Los Angeles",
      },
    },
    {
      image: "https://sundarjodi.com/img/3marathi-couple.png",
      profile: {
        name: "Jane Smith",
        occupation:
          "Perfect for what i needed. Found my Lenders almost instantly. who use again. Perfect for what i needed. Found my Lenders almost instantly. who use again.",
        // location: "Los Angeles",
      },
    },
    {
      image: "https://sundarjodi.com/img/2marathi-couple.png",
      profile: {
        name: "Rupesh & Priyanka",
        occupation:
          "Perfect for what i needed. Found my Lenders almost instantly. who use again. Perfect for what i needed. Found my Lenders almost instantly. who use again.",
        // location: "Los Angeles",
      },
    },
    // Add more data as needed
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column" }}>
      <Snow />

      <div
    
        className="banner"
      >
      <span style={{ color: "white", fontSize: "50px" }}>
      Search your Life partner
    </span>
    <div className="search-container" onClick={() => setOpenModal(true)}>
      <input
        value="Search your Loveones"
        readOnly
        type="text"
        placeholder="Search..."
        className="search-input"
      />
      <img className="search-icon" />
    </div>

    <Modal open={openModal} onClose={() => setOpenModal(false)}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleFormSubmit(searchvalues);
        }}
      >
        <div
          className="modal-container"
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            backgroundColor: "white",
            padding: "20px",
            width: "80%",
            maxWidth: "500px",
            borderRadius: "10px",
            display: "grid",
            gridTemplateColumns: "repeat(2, 1fr)",
            gap: "20px",
          }}
        >
          <button
            onClick={() => setOpenModal(false)}
            style={{
              position: "absolute",
              // bottom:"-5px",
              top: "-3px",
              right: "8px",
              backgroundColor: "transparent",
              border: "none",
              cursor: "pointer",
              fontSize: "1.5rem",
            }}
          >
            X
          </button>
          <input
            type="text"
            placeholder="Gender"
            onChange={(e) =>
              setSearchvalues({ ...searchvalues, gender: e.target.value })
            }
            value={searchvalues.gender}
            className="modal-input"
          />
          <input
            type="text"
            placeholder="Age"
            onChange={(e) =>
              setSearchvalues({ ...searchvalues, age: e.target.value })
            }
            value={searchvalues.age}
            className="modal-input"
          />
          <input
            type="text"
            placeholder="Occupation"
            onChange={(e) =>
              setSearchvalues({ ...searchvalues, occupation: e.target.value })
            }
            value={searchvalues.occupation}
            className="modal-input"
          />
          <input
            type="text"
            placeholder="Caste"
            onChange={(e) =>
              setSearchvalues({ ...searchvalues, caste: e.target.value })
            }
            value={searchvalues.caste}
            className="modal-input"
          />
          <input
            type="text"
            placeholder="Color"
            onChange={(e) =>
              setSearchvalues({ ...searchvalues, color: e.target.value })
            }
            value={searchvalues.color}
            className="modal-input"
          />
          <input
            type="text"
            placeholder="Height"
            onChange={(e) =>
              setSearchvalues({ ...searchvalues, height: e.target.value })
            }
            value={searchvalues.height}
            className="modal-input"
          />
          <input
            type="text"
            placeholder="City"
            onChange={(e) =>
              setSearchvalues({ ...searchvalues, city: e.target.value })
            }
            value={searchvalues.city}
            className="modal-input"
          />
          <input
            type="text"
            placeholder="Religion"
            onChange={(e) =>
              setSearchvalues({ ...searchvalues, religion: e.target.value })
            }
            value={searchvalues.religion}
            className="modal-input"
          />
          <button
            style={{
              backgroundColor: "#DC3545",
              width: "80px",
              height: "30px",
              borderRadius: "10px",
            }}
            type="submit"
          >
            Search
          </button>
        </div>
      </form>
    </Modal>
      </div>

      

      <div className="bannertwo"></div>
      {showMatchingCarousel && matchingProfiles.length > 0 && (
        <Carousel
          responsive={responsive}
          swipeable={true}
          draggable={true}
          showDots={true}
          infinite={true}
          autoPlay={true}
          autoPlaySpeed={1000}
          keyBoardControl={true}
          customTransition="all .5"
          transitionDuration={500}
          containerClass="carousel-container"
          removeArrowOnDeviceType={["tablet", "mobile"]}
          deviceType={"desktop"}
          dotListClass="custom-dot-list-style"
          itemClass="carousel-item-padding-40-px"
          renderButtonGroupOutside={true}
          arrows={false}
        >
          {matchingProfiles.map((item, index) => (
            <div
              style={{
                display: "flex",
                paddingLeft: "90px",
                // justifyContent: "center",
                // alignItems: "center",
                marginTop: "30px",
              }}
              key={index}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  borderRadius: "20px",
                  alignItems: "center",
                  flexDirection: "column",
                  width: "70%",
                  backgroundColor: "#98ff98",
                  position: "relative",
                }}
                className="carousel-item"
              >
                <Avatar
                  alt="Remy Sharp"
                  src={item.imagePath}
                  sx={{ width: 80, height: 80 }}
                />
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    paddingLeft: "40px",
                  }}
                >
                  <span
                    style={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#333",
                      fontFamily: "serif",
                      width: "200px",
                    }}
                  >
                    name: {item.username}
                  </span>
                  <span
                    style={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#333",
                      fontFamily: "serif",
                      width: "200px",
                    }}
                  >
                    age: {item.age}
                  </span>
                  <span
                    style={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#333",
                      fontFamily: "serif",
                      width: "200px",
                    }}
                  >
                    caste: {item.caste}
                  </span>
                  <span
                    style={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#333",
                      fontFamily: "serif",
                      width: "200px",
                    }}
                  >
                    city: {item.city}
                  </span>
                  <span
                    style={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#333",
                      fontFamily: "serif",
                      width: "200px",
                    }}
                  >
                    gender: {item.gender}
                  </span>
                  <span
                    style={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#333",
                      fontFamily: "serif",
                      width: "200px",
                    }}
                  >
                    occupation: {item.occupation}
                  </span>
                  <span
                    style={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#333",
                      fontFamily: "serif",
                      width: "200px",
                    }}
                  >
                    religion: {item.religion}
                  </span>
                  <span
                    style={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#333",
                      fontFamily: "serif",
                      width: "200px",
                    }}
                  >
                    state: {item.state}
                  </span>
                </div>
                <div style={{ position: "absolute", left: "0", bottom: "0" }}>
                  <img
                    onClick={() => handleWhatsAppClick(item)}
                    style={{ width: "40px", height: "40px" }}
                    src={whatsapp}
                    alt="WhatsApp"
                  />
                </div>
                <div style={{ position: "absolute", right: "0", bottom: "0" }}>
                  <img
                    style={{ width: "40px", height: "40px" }}
                    src={call}
                    alt="Call"
                  />
                </div>
              </div>
            </div>
          ))}
        </Carousel>
      )}

      {!showMatchingCarousel && (
        <Carousel
          responsive={responsive}
          swipeable={true}
          draggable={true}
          showDots={true}
          infinite={true}
          autoPlay={true}
          autoPlaySpeed={2000}
          keyBoardControl={true}
          customTransition="all .5"
          transitionDuration={500}
          containerClass="carousel-container"
          removeArrowOnDeviceType={["tablet", "mobile"]}
          deviceType={"desktop"}
          dotListClass="custom-dot-list-style"
          itemClass="carousel-item-padding-40-px"
          renderButtonGroupOutside={true}
          arrows={false}
        >
          {sortedData.map((item, index) => (
            <div
              style={{
                display: "flex",
                paddingLeft: "90px",
                // justifyContent: "center",
                // alignItems: "center",
                marginTop: "50px",
              }}
              key={index}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  borderRadius: "20px",
                  alignItems: "center",
                  flexDirection: "column",
                  width: "70%",
                  backgroundColor: "#98ff98",
                  position: "relative",
                }}
                className="carousel-item"
              >
                <Avatar
                  alt="Remy Sharp"
                  src={item.imagePath}
                  sx={{ width: 80, height: 80 }}
                />
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    paddingLeft: "40px",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <span
                    style={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#333",
                      fontFamily: "serif",
                      width: "200px",
                    }}
                  >
                    name: {item.username}
                  </span>
                  <span
                    style={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#333",
                      fontFamily: "serif",
                      width: "200px",
                    }}
                  >
                    age: {item.age}
                  </span>
                  <span
                    style={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#333",
                      fontFamily: "serif",
                      width: "200px",
                    }}
                  >
                    caste: {item.caste}
                  </span>
                  <span
                    style={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#333",
                      fontFamily: "serif",
                      width: "200px",
                    }}
                  >
                    city: {item.city}
                  </span>
                  <span
                    style={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#333",
                      fontFamily: "serif",
                      width: "200px",
                    }}
                  >
                    gender: {item.gender}
                  </span>
                  <span
                    style={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#333",
                      fontFamily: "serif",
                      width: "200px",
                    }}
                  >
                    occupation: {item.occupation}
                  </span>
                  <span
                    style={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#333",
                      fontFamily: "serif",
                      width: "200px",
                    }}
                  >
                    religion: {item.religion}
                  </span>
                  <span
                    style={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#333",
                      fontFamily: "serif",
                      width: "200px",
                    }}
                  >
                    state: {item.state}
                  </span>
                </div>
                <div style={{ position: "absolute", left: "0", bottom: "0" }}>
                  <img
                    onClick={() => handleWhatsAppClick(item)}
                    style={{ width: "40px", height: "40px" }}
                    src={whatsapp}
                    alt="WhatsApp"
                  />
                </div>
                <div style={{ position: "absolute", right: "0", bottom: "0" }}>
                  <img
                    style={{ width: "40px", height: "40px" }}
                    src={call}
                    alt="Call"
                  />
                </div>
              </div>
            </div>
          ))}
        </Carousel>
      )}

     

      
      <span
        style={{
          textAlign: "center",
          marginTop: "80px",
          textAlign: "center",
          fontSize: "40px",
          fontWeight: "500",
          fontFamily: "serif",
          lineHeight: 1.2,
        }}
      >
        Best & Trusted Matrimony Website
      </span>

      <Grid container spacing={4} style={{ marginTop: "20px" }}>
        {/* Left section on small screens */}
        <Grid item xs={12} sm={6}>
          <Paper style={{ height: "auto", padding: "20px" }}>
            <img
              style={{ width: "100%", height: "100%" }}
              src="https://sundarjodi.com/img/bg1.jpg"
            />
          </Paper>
        </Grid>

        {/* Right section on small screens */}
        <Grid item xs={12} sm={6}>
          <Paper
            style={{
              height: "auto",
              padding: "20px",
            }}
          >
            {/* My Profile List 1 */}
            <div className="profileList">
              <div className="content">
                <p>
                  Our Hogamilan matrimony site allows thousands of verified
                  profiles
                </p>
                <div className="toggleBtn" onClick={toggleContent}>
                  {showContent ? "-" : "+"}
                </div>
              </div>
              {showContent && (
                <div className="content">
                  As one of the leading matrimony sites, we believe that there
                  should not be any compromise while selecting your life
                  partner. Our Vadhu Var Suchak Kendra has served lakhs of
                  singles who have found their ideal match with active 5000+
                  verified profiles.
                </div>
              )}
            </div>

            {/* My Profile List 2 */}
            <div className="profileList">
              <div className="content">
                <p>
                  Find a perfect life partner from one of the leading Matrimony
                  Sites Hogamilan
                </p>
                <div className="toggleBtn" onClick={handleOpen}>
                  {item ? "-" : "+"}
                </div>
              </div>
              {item && (
                <div className="content">
                  We understand that in Hogamilan matrimony is not just a union
                  of two individuals but two families. We offer profiles from
                  400+ castes to find your future spouse that would be the
                  perfect addition to your family.
                </div>
              )}
            </div>

            {/* My Profile List 3 */}
            <div className="profileList">
              <div className="content">
                <p>
                  Hogamilan matrimonial site that is dedicated to matchmaking
                </p>
                <div className="toggleBtn" onClick={handleClose}>
                  {data ? "-" : "+"}
                </div>
              </div>
              {data && (
                <div className="content">
                  Matchmaking is not simply business for us; it is an emotion.
                  It gives us great pleasure to see two people happily settled
                  in matrimony. Sundar Jodi as a Vadhu Var Suchak has proudly
                  fixed successful matches till now.
                </div>
              )}
            </div>

            {/* My Profile List 4 */}
            <div className="profileList">
              <div className="content">
                <p>
                  Hogamilan matrimony site with a blend of Tradition and
                  Technology
                </p>
                <div className="toggleBtn" onClick={handleData}>
                  {dataitem ? "-" : "+"}
                </div>
              </div>
              {dataitem && (
                <div className="content">
                  In the present time, it is necessary to blend our traditions
                  with technology to find your soul mate. As one of the trusted
                  matrimony Hogamilan sites, we find matches both online and
                  offline based on caste, family culture, and horoscopes.
                </div>
              )}
            </div>

            {/* My Profile List 5 */}
            <div className="profileList">
              <div className="content">
                <p>
                  Hogamilan matrimony site with filters to find your perfect
                  match
                </p>
                <div className="toggleBtn" onClick={handleStore}>
                  {store ? "-" : "+"}
                </div>
              </div>
              {store && (
                <div className="content">
                  With liberal thoughts and values among couples, they prefer to
                  marry someone who is their equal and meets their expectations
                  of compatibility. On our Marathi matrimonial website, you can
                  filter your options on the basis of education background, job,
                  state/city of residence, etc.
                </div>
              )}
            </div>

            {/* My Profile List 6 */}
            <div className="profileList">
              <div className="content">
                <p>
                  Hogamilan Matrimonial Website with 100% Data Security and
                  Privacy
                </p>
                <div className="toggleBtn" onClick={handleStoreItem}>
                  {storeitem ? "-" : "+"}
                </div>
              </div>
              {storeitem && (
                <div className="content">
                  Your data security is of utmost importance to us. As one of
                  the reputed matrimonial Hogamilan sites, we undertake every
                  precaution and effort to ensure that your information on this
                  platform is completely safe.
                </div>
              )}
            </div>

            {/* My Profile List 7 */}
            <div className="profileList">
              <div className="content">
                <p>Help Center and Online Support</p>
                <div className="toggleBtn" onClick={handleMount}>
                  {mount ? "-" : "+"}
                </div>
              </div>
              {mount && (
                <div className="content">
                  Matrimony is a big decision in anyone’s life, and the
                  matrimony site Marathi is here to support and help you in
                  every step you take to find your better half.
                </div>
              )}
            </div>
          </Paper>
        </Grid>
      </Grid>
      <div
        style={{
          display: "flex",
          marginTop: "80px",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          // gap:"30px"
        }}
      >
        <h1>Success Stories</h1>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            marginTop: "30px",
          }}
        >
          <span style={{ textAlign: "center" }}>
            Presenting the family of the happy couples who found their sundar
            jodidar via this free matchmaking website .
          </span>
          <span style={{ textAlign: "center" }}>
            If your story was also directed by us, send your engagement or
            wedding photos and get featured on our hall of sundar stories.
          </span>
        </div>
      </div>
      <br></br>
      <Carousel
        swipeable={true}
        draggable={true}
        showDots={true}
        infinite={true}
        autoPlay={true}
        autoPlaySpeed={1000}
        keyBoardControl={true}
        customTransition="all .5"
        transitionDuration={500}
        containerClass="carousel-container"
        removeArrowOnDeviceType={["tablet", "mobile"]}
        deviceType={"desktop"}
        dotListClass="custom-dot-list-style"
        itemClass="carousel-item-padding-40-px"
        renderButtonGroupOutside={true}
        arrows={false}
        responsive={responsive}
      >
        {datastorage.map((item, index) => (
          <div
            style={{
              display: "flex",

              width: "80%",

              justifyContent: "center",
              alignItems: "center",
              flexDirection: "column",
              borderRadius: "20px",
            }}
            key={index}
          >
            <div
              style={{
                display: "flex",
                width: "80%",
                height: "80%",

                // backgroundColor: "green",
              }}
            >
              <img
                style={{ width: "80%", borderRadius: "20px", height: "80%" }}
                src={item.image}
                alt={`Image ${index}`}
              />
            </div>
            <br></br>
            <div
              style={{
                display: "flex",
                width: "90%",
                flexDirection: "column",
                justifyContent: "flex-start",
                // backgroundColor: "red",
              }}
            >
              <h3>{item.profile.name}</h3>
              <p>{item.profile.occupation}</p>
            </div>
          </div>
        ))}
      </Carousel>

      <div
        style={{
          display: "flex",
          alignItems: "center",
          marginTop: "40px",
          width: "100%",
          backgroundColor: "#DC3545",
          height: "90px",
        }}
      >
        <p style={{ fontSize: "30px", paddingLeft: "20px", color: "white" }}>
          Your story is waiting to happen!
        </p>
      </div>

      <div
        style={{
          display: "flex",
          marginTop: "40px",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            width: "40%",
            height: "100%",
          }}
        >
          <span style={{ fontSize: "25px", fontWeight: "700" }}>
            About <span style={{ color: "#DC3545" }}>Hogamilan</span>
          </span>
          <span>Discover lasting connections with</span>
          <span>Hogamilan.com, your trusted</span>
          <span>matrimony platform. Explore</span>
          <span>personalized matchmaking and</span>
          <span>matrimonial services for a</span>
          <span>meaningful journey to love.</span>
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              marginTop: "20px",
              gap: "20px",
            }}
          >
            <img style={{ width: "40px" }} src={facebook} />
            <img style={{ width: "40px" }} src={instagram} />
          </div>
        </div>
        <div
          style={{
            display: "flex",
            width: "25%",
            height: "100%",
            marginBottom: "90px",
            flexDirection: "column",
          }}
        >
          <span style={{ fontSize: "25px", fontWeight: "700" }}>
            Quick <span>Links</span>
          </span>
          <span>About Us</span>
          <span>Blog</span>
          <span>Contact Us</span>
        </div>
        <div
          style={{
            display: "flex",
            width: "25%",
            height: "100%",
            marginBottom: "90px",
            flexDirection: "column",
          }}
        >
          <span style={{ fontSize: "25px", fontWeight: "700" }}>Policy</span>
          <span>Disclaimer</span>
          <span>Privacy Policy</span>
          <span>Terms of service</span>
          <span>FAQs</span>
        </div>
      </div>
      <audio loop>
        <source
          src="https://www.pagalworldl.com/files/download/id/9363"
          type="audio/mpeg"
        />
      </audio>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          width: "100%",
          marginTop: "90px",
          backgroundColor: "#DC3545",
          height: "60px",
        }}
      >
        <p style={{ fontSize: "15px", fontWeight: "bold", color: "white" }}>
          Copyright © 2024 - Hogamilan - All Rights Reserved
        </p>
      </div>
    </div>
  );
}

export default Homepage;
