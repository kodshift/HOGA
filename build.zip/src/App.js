import React from "react";
import Navigators from "./navigation/Navigators";


function App() {
  return (
    <div >
<Navigators/>
    </div>
  );
}

export default App;
